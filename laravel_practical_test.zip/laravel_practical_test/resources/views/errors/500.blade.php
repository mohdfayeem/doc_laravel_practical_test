<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>500</title>
</head>

<body>

    <h1>500</h1>
    <h2>Internal Server Error</h2>
    <p>
        <a href="{{ url('/') }}">Home</a>
    </p>

</body>

</html>
