<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Edit Category</div>

                <div class="card-body">
                    <?php if(Session::has('response_message')): ?>
                    <div class="alert <?php echo e(Session::get('response_class')); ?>" role="alert">
                        <span><?php echo e(Session::get('response_message')); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <div class="small">
                            <h6><i class='fa fa-exclamation-triangle'></i> Please correct these error</h6>
                            <ul class="list-unstyled mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="small"><i class="fa fa-circle"></i> <?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <?php endif; ?>

                    <form action="<?php echo e(url('/admin/edit-category/'.$id)); ?>" method="post" id="edit_category_form" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label for="name" class="form-label">Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="name" id="name" placeholder="Enter Category Name" value="<?php echo e($category_details['name']); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label for="email" class="form-label">Email<span class="text-danger">*</span></label>
                                    <input type="email" class="form-control" name="email" id="email" placeholder="Enter Category email" value="<?php echo e($category_details['email_id']); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label for="image" class="form-label">Image</label>
                                    <input class="form-control" type="file" id="image" name="image" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <h5>Subcategories Details:</h5>
                            <?php $__currentLoopData = $category_details['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label for="subcategoryname" class="form-label">Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="subcategoryname[]" placeholder="Enter Subcategory Name" value="<?php echo e($subcategory['name']); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label for="subcategoryemail" class="form-label">Email<span class="text-danger">*</span></label>
                                    <input type="email" class="form-control" name="subcategoryemail[]" placeholder="Enter Subcategory Email" value="<?php echo e($subcategory['email_id']); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-3 mt-4 pt-1">
                                    <?php if($key == 0): ?>
                                    <button type="button" class="btn btn-primary add-subcategory-fields-btn">+</button>
                                    <?php endif; ?>
                                    <?php if(count($category_details['subcategories']) > 1): ?>
                                    <button type="button" class="btn btn-danger remove-btn" data-id="<?php echo e($subcategory['id']); ?>" data-url="/admin/delete-subcategory">-</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="container-fluid p-0" id="append_subcategory_container">
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-success">Edit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\laravel_practical_test\resources\views/admin/edit-category.blade.php ENDPATH**/ ?>