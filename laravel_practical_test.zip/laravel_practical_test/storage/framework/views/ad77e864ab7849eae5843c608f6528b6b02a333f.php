<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Add Category</div>

                <div class="card-body">
                <?php if(Session::has('response_message')): ?>
                    <div class="alert <?php echo e(Session::get('response_class')); ?>" role="alert">
                        <span><?php echo e(Session::get('response_message')); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <div class="small">
                            <h6><i class='fa fa-exclamation-triangle'></i> Please correct these error</h6>
                            <ul class="list-unstyled mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="small"><i class="fa fa-circle"></i> <?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <?php endif; ?>

                    <form action="<?php echo e(url('/admin/add-category')); ?>" method="post" id="add_category_form" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label for="name" class="form-label">Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="name" id="name" placeholder="Enter Category Name" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label for="email" class="form-label">Email<span class="text-danger">*</span></label>
                                    <input type="email" class="form-control" name="email" id="email" placeholder="Enter Category email" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label for="image" class="form-label">Image</label>
                                    <input class="form-control" type="file" id="image" name="image" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <h5>Subcategories Details:</h5>
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label for="subcategoryname" class="form-label">Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="subcategoryname[]" placeholder="Enter Subcategory Name" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label for="subcategoryemail" class="form-label">Email<span class="text-danger">*</span></label>
                                    <input type="email" class="form-control" name="subcategoryemail[]" placeholder="Enter Subcategory Email" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-3 mt-4 pt-1">
                                    <button type="button" class="btn btn-primary add-subcategory-fields-btn">+</button>
                                </div>
                            </div>
                        </div>
                        <div class="container-fluid p-0" id="append_subcategory_container">
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-success">Add</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\laravel_practical_test\resources\views/admin/add-category.blade.php ENDPATH**/ ?>