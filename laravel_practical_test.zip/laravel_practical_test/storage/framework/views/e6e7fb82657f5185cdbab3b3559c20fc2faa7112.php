<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404</title>
</head>

<body>

    <h1>404</h1>
    <h2>Page Not Found</h2>
    <p>
        <a href="<?php echo e(url('/')); ?>">Home</a>
    </p>

</body>

</html>
<?php /**PATH C:\wamp64\www\laravel\laravel_practical_test\resources\views/errors/404.blade.php ENDPATH**/ ?>