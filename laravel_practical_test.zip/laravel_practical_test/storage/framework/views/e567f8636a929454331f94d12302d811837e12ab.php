<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center g-3">
        <div class="col-md-12 clearfix">
            <div class="float-end">
                <a href="<?php echo e(url('/admin/add-category')); ?>" class="btn btn-primary">Add category</a>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Image</th>
                                    <th>Subcategory</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($category['name']); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('images/category/'.$category['image'])); ?>" alt="Img" style="width: 80px; height: auto;">
                                    </td>
                                    <td>
                                        <ul class="list-unstyled">
                                            <?php $__currentLoopData = $category['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-unstyled-item"><?php echo e($subcategory['name']); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(url('/admin/edit-category/'. $category['id'])); ?>">Edit</a>
                                        <a href="javascript:void(0);" class="remove-btn" data-id="<?php echo e($category['id']); ?>" data-url="/admin/delete-category">Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="row">
                        <div class="col-12 clearfix">
                            <div class="pagination pagination-secondary float-end pagination-sm" id="privateCategoryPagination">
                                <?php echo e($categories->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\laravel_practical_test\resources\views/home.blade.php ENDPATH**/ ?>